#include "enemy.h"
#include "math.h"
Enemy::Enemy(){}
Enemy::Enemy(QPoint epo,int level):_epo(epo),_level(level),_direction(4),_live(false),_speed(0)
{
    if(level==1)
        _speed=8;
    if(level==2)
        _speed=9;
    if(level==3)
        _speed=10;
    if(level==4)
        _speed=12;
    _direction=4;//刚开始出现时敌人前进的方向都是向右
    _live=false;//生命初始值
}
void Enemy::setDirection(int newdirection){
    _direction=newdirection;
}
QPoint Enemy::getEpo(){
    return _epo;//返回当前的位置
}
void Enemy::Nextposition(){
    if(_direction==1)
        _epo.setY(_epo.y()-_speed);
    if(_direction==2)
        _epo.setY(_epo.y()+_speed);
    if(_direction==3)
        _epo.setX(_epo.x()-_speed);
    if(_direction==4)
        _epo.setX(_epo.x()+_speed);

}
bool Enemy::getlife(){
    return _live;
}
double Enemy::distance(QPoint p1, QPoint p2){
    double s1;
    s1=sqrt((p1.x()-p2.x())*(p1.x()-p2.x())+(p1.y()-p2.y())*(p1.y()-p2.y()));
    return s1;
}
void Enemy::turn(QPoint p[2]){
    if(distance(_epo,p[0])<30)
        _direction=2;
    if(distance(_epo,p[1])<30)
        _direction=4;
}
void Enemy::giveBirth(){
    _live=true;//产生
    QMediaPlayer *playere=new QMediaPlayer;
    playere->setMedia(QUrl("qrc:/new/prefix1/birthsound.mp3"));
    playere->setVolume(40);
    playere->play();
}
int Enemy::getlevel(){
    return _level;
}
