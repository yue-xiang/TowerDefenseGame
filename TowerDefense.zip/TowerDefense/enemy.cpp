#include "enemy.h"

Enemy::Enemy(QPoint epo,int level):_epo(epo),_level(level)
{
    if(level==1)
        _speed=10;
    if(level==2)
        _speed=20;
    _direction=4;//刚开始出现时敌人前进的方向都是向右

}
void Enemy::setDirection(int newdirection){
    _direction=newdirection;
}
QPoint Enemy::getEpo(){
    return _epo;
}
void Enemy::Nextposition(){
    if(_direction==1)
        _epo.setY(_epo.y()-_speed);
    if(_direction==2)
        _epo.setY(_epo.y()+_speed);
    if(_direction==3)
        _epo.setX(_epo.x()-_speed);
    if(_direction==4)
        _epo.setX(_epo.x()+_speed);

}
