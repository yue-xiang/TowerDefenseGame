#ifndef ENEMY_H
#define ENEMY_H

#include <QMainWindow>
#include <QWidget>

class Enemy
{
public:
    Enemy(QPoint epo,int level);
    void setDirection(int newdirection);
    QPoint getEpo();//获得敌人的位置
    void Nextposition();

private:
    QPoint _epo;
    int _level;//敌人的等级
    int _direction,_speed;//1234分别代表方向上下左右
    bool _live;//生命值
};

#endif // ENEMY_H
