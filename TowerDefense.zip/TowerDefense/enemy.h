#ifndef ENEMY_H
#define ENEMY_H

#include <QMainWindow>
#include <QWidget>
#include <QMediaPlayer>
class Enemy
{
public:
    Enemy(){};

    Enemy(QPoint epo,int level);
    void setDirection(int newdirection);
    QPoint getEpo();//获得敌人的位置
    void Nextposition();
    bool getlife();//获取生命值
    void turn(QPoint p[2]);//调转行进方向
    double distance(QPoint p1,QPoint p2);
    void giveBirth();
    int getlevel();
    void beat();//被攻击一次，调用该函数一次
    void declareDeath();
    int getBeattime();
    int Showvalue();
    bool hasCal();
    void setHascal();
private:
    QPoint _epo;
    int _level;//敌人的等级
    int _direction;//1234分别代表方向上下左右
    double _speed;
    bool _live;//生命值
    int _beattime;//抗打击次数
    int value=0;//自身价值，死亡之后由0变成25
    bool hascal;
};

#endif // ENEMY_H
