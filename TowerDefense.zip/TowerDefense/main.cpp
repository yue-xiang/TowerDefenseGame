#include "mainwindow.h"
#include "dialog.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    Dialog d;
    d.setFixedSize(800,600);

    //w.setFixedSize(800,600);
    if(d.getsignal()==false)
       d.show();
    //else
    //    d.hide();
    return a.exec();
}
