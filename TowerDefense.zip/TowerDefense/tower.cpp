#include "tower.h"
Tower::Tower(const QPoint po):_po(po)
{
    _po=po;
    hasTower=false;
    standard=false;

}
void Tower::sethasTower(){
    hasTower=true;
}
void Tower::setstandard(){
    standard=true;
}
QPoint Tower::getp(){
    return _po;}
bool Tower::gethasTower(){
    return hasTower;
}
bool Tower::getstandard(){
    return standard;
}
bool Tower::clickrange(int x,int y){
    bool X1=x>=_po.x()&&x<=(_po.x()+55);
    //bool X2=p.x()<(_po.x()&&p.x()>_po.x()+20;
    bool Y1=y>=_po.y()&&y<=(_po.y()+55);
    //bool Y2=p.y()<_po.y()&&p.y()>_po.y()+25;
    if(X1&&Y1)
        return true;
    else
        return false;
}
