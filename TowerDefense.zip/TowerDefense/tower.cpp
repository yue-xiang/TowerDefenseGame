#include "tower.h"
QMediaPlayer *play=new QMediaPlayer;
Tower::Tower(const QPoint po):_po(po)
{
    _po=po;
    hasTower=false;
    standard=false;

}
void Tower::sethasTower(){
    hasTower=true;

}
void Tower::setmusic(){
    play->setMedia(QUrl("qrc:/new/prefix1/tower.mp3"));
    play->setVolume(30);
    play->play();
}
void Tower::setstandard(){
    standard=true;
}
QPoint Tower::getp(){
    return _po;}
bool Tower::gethasTower(){
    return hasTower;
}
bool Tower::getstandard(){
    return standard;
}
bool Tower::clickrange(int x,int y){
    bool X1=x>=_po.x()&&x<=(_po.x()+55);
    //bool X2=p.x()<(_po.x()&&p.x()>_po.x()+20;
    bool Y1=y>=_po.y()&&y<=(_po.y()+55);
    //bool Y2=p.y()<_po.y()&&p.y()>_po.y()+25;
    if(X1&&Y1)
        return true;
    else
        return false;
}
double Tower::calDistance(QPoint p1, QPoint p2){
    double s1;
    s1=sqrt((p1.x()-p2.x())*(p1.x()-p2.x())+(p1.y()-p2.y())*(p1.y()-p2.y()));
    return s1;

}
void Tower::attack(Enemy enemy[11]){
    for(int i=0;i<=10;i++){
        if(calDistance(_po,enemy[i].getEpo())<=_range&&enemy[i].getlife()>0&&gethasTower()>0)
        {
            enemy[i].beat();
            play->setMedia(QUrl("qrc:/new/prefix1/puttower.mp3"));
            play->setVolume(30);
            play->play();
        }
        if(enemy[i].getBeattime()==0){
            enemy[i].declareDeath();
            enemy[i].beat();//处理死亡的音效，避免重复

        }
    }
}
int Tower::getRange(){
    return _range;
}
void Tower::reSetstandard(){
    standard=false;
}
