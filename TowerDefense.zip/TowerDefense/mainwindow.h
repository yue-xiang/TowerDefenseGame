#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPaintEngineState>
#include <QPainter>
#include <QPoint>
#include <tower.h>
#include <enemy.h>
#include <QTimerEvent>


QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    //explicit MainWindow(QWidget *parent=0);
    MainWindow(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent *);
    void mousePressEvent(QMouseEvent *);
   // bool clickrange(const QPoint p,int i);
    void timerEvent(QTimerEvent *event);
    ~MainWindow();
    //int money=50;
    void getValue();
    void declareend();
    //int showend();
private slots:

private:
    Ui::MainWindow *ui;
    const int _width=44,_height=44;
   QPoint point[16]={
        QPoint(100,280),
        QPoint(190,280),
        QPoint(280,280),
        QPoint(100,140),
        QPoint(190,140),
        QPoint(280,140),
        QPoint(370,140),
        QPoint(440,240),

        QPoint(300,400),
        QPoint(500,300),
        QPoint(590,300),
        QPoint(680,300),
        QPoint(480,450),
        QPoint(570,450),
        QPoint(660,450),
        QPoint(390,450)};

    Tower tower[16]={
            Tower(QPoint(90,260)),
            Tower(QPoint(180,260)),
            Tower(QPoint(270,260)),
            Tower(QPoint(90,120)),
            Tower(QPoint(180,120)),
            Tower(QPoint(270,120)),
            Tower(QPoint(360,120)),
            Tower(QPoint(430,220)),
            Tower(QPoint(290,380)),
            Tower(QPoint(490,280)),
            Tower(QPoint(580,280)),
            Tower(QPoint(670,280)),
            Tower(QPoint(470,430)),
            Tower(QPoint(560,430)),
            Tower(QPoint(650,430)),
            Tower(QPoint(380,430))};
    QPoint turn[2]={QPoint(400,200),QPoint(400,360)};//起点终点：QPoint(85,200),QPoint(660,360)
    Enemy enemy[11]={
         Enemy(QPoint(75,200),1),
         Enemy(QPoint(75,200),1),
         Enemy(QPoint(75,200),2),
         Enemy(QPoint(75,200),2),
         Enemy(QPoint(75,200),2),
         Enemy(QPoint(75,200),3),
         Enemy(QPoint(75,200),3),
         Enemy(QPoint(75,200),3),
         Enemy(QPoint(75,200),4),
         Enemy(QPoint(75,200),4),
        Enemy(QPoint(75,200),4)

    };
    int end;
protected:
    int money=50;







};
#endif // MAINWINDOW_H
