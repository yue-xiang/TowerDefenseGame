#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPaintEngineState>
#include <QPainter>
#include <QPoint>
#include <tower.h>
#include <enemy.h>
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void paintEvent(QPaintEvent *);
    void mousePressEvent(QMouseEvent *);
    bool clickrange(const QPoint p,int i);

private:
    Ui::MainWindow *ui;
    const int _width=44;
    const int _height=44;
    QPoint point[16]={
        QPoint(100,280),
        QPoint(190,280),
        QPoint(280,280),
        QPoint(100,140),
        QPoint(190,140),
        QPoint(280,140),
        QPoint(370,140),
        QPoint(440,240),

        QPoint(300,400),
        QPoint(500,300),
        QPoint(590,300),
        QPoint(680,300),
        QPoint(480,450),
        QPoint(570,450),
        QPoint(660,450),
        QPoint(390,450)};

        Tower tower[16]={
            Tower(QPoint(90,250)),
            Tower(QPoint(180,250)),
            Tower(QPoint(270,250)),
            Tower(QPoint(90,110)),
            Tower(QPoint(180,110)),
            Tower(QPoint(270,110)),
            Tower(QPoint(360,110)),
            Tower(QPoint(430,210)),
            Tower(QPoint(290,370)),
            Tower(QPoint(490,270)),
            Tower(QPoint(580,270)),
            Tower(QPoint(670,270)),
            Tower(QPoint(470,420)),
            Tower(QPoint(560,420)),
            Tower(QPoint(650,420)),
            Tower(QPoint(380,420))};
        QPoint turn[4]={QPoint(370,200),QPoint(370,360),QPoint(85,200),QPoint(660,360)};



};
#endif // MAINWINDOW_H
