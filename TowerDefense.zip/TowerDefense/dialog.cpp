#include "dialog.h"
#include "ui_dialog.h"
#include "mainwindow.h"
#include "QPushButton"
#include <QMediaPlayer>

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
    _signal=false;
    QMediaPlayer *player=new QMediaPlayer;
    player->setMedia(QUrl("qrc:/new/prefix1/bgm2.mp3"));
    player->setVolume(30);
    player->play();


}
void Dialog::paintEvent(QPaintEvent *){
    QPainter painter (this);
    painter.drawPixmap(rect(),QPixmap(":/new/prefix1/open.png"));

}
Dialog::~Dialog()
{
    delete ui;
}
bool Dialog::getsignal(){
    return _signal;
}




//void Dialog::on_pushButton_pressed()
//{
//    _signal=true;
//}

void Dialog::on_pushButton_clicked()
{
    if(_signal==false){
        MainWindow *a=new MainWindow;
        a->setFixedSize(800,600);
        a->show();
    }

    _signal=true;
}
