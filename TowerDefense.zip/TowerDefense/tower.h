#ifndef TOWER_H
#define TOWER_H
#include <QPoint>
#include <QSize>
#include <QMediaPlayer>
#include <enemy.h>
#include <math.h>
//#include <mainwindow.h>
class Tower
{
public:
    Tower (){};
    Tower(const QPoint po);
    void sethasTower();
    QPoint getp();
    bool gethasTower();
    bool clickrange(int x,int y);
    void setstandard();
    bool getstandard();
    void setmusic();
    void attack(Enemy enemy[11]);
    double calDistance(QPoint p1,QPoint p2);
    int getRange();
    void reSetstandard();

private:
    bool hasTower;
    bool standard;
    QPoint _po;
    int  _range=90;
};

#endif // TOWER_H
