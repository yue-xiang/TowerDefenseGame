#ifndef TOWER_H
#define TOWER_H
#include <QPoint>
#include <QSize>
class Tower
{
public:
    Tower (){};
    Tower(const QPoint po);
    void sethasTower();
    QPoint getp();
    bool gethasTower();
    bool clickrange(int x,int y);
    void setstandard();
    bool getstandard();

private:
    bool hasTower;
    bool standard;
    QPoint _po;
};

#endif // TOWER_H
