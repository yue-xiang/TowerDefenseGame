#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include "mainwindow.h"
#include <QPaintEvent>
#include <QPainter>

namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog(QWidget *parent = nullptr);
    ~Dialog();
    void paintEvent(QPaintEvent *);
    bool getsignal();


private slots:
    //void on_pushButton_pressed();

    void on_pushButton_clicked();

private:
    Ui::Dialog *ui;
    bool _signal;


};

#endif // DIALOG_H
