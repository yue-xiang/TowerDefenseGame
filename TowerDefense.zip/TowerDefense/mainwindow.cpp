#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "tower.h"
#include "enemy.h"
#include <QMouseEvent>
//#include <dialog.h>
#include <QTime>
#include <QDebug>
#include <QLabel>
#include <QString>

int j=0;
//QMediaPlayer *play=new QMediaPlayer;
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->Money->setPixmap(QPixmap(":/new/prefix1/moneybar.png"));
    startTimer(300);
    startTimer(5000);
    startTimer(1000);
    startTimer(500);
    //ui->Money->setPixmap(QPixmap(":/new/prefix1/moneybar.png"));


    QString s2=QString::number(money);
    QString s1="Money:";
    QString s=s1.append(s2);
    ui->Money->setText(s);
    end=0;






}

void MainWindow::getValue(){
    for(int i=0;i<10;i++){
        if(enemy[i].hasCal()==false)
        money+=enemy[i].Showvalue();
        if(enemy[i].Showvalue()==25)
            enemy[i].setHascal();
    }
}
void MainWindow::declareend(){
   int add=0;
    //for(int i=0;i<11;i++){
    //    if(enemy[i].getEpo().x()>680&&enemy[i].getlife()){

    //        end=1;//失败
    //        break;
    //    }
    //}

    //成功的情况
    for(int i=0;i<1;i++){
       if(enemy[i].getBeattime()==0)
            add+=1;
    }
    if(add==1)
        end=2;

}
void MainWindow::paintEvent(QPaintEvent *){


   QPainter painter(this);
   painter.drawPixmap(rect(),QPixmap(":/new/prefix1/map2"),QRect());;
    for(int i=0;i<16;i++){
        if(end==0)
        painter.drawPixmap(point[i].x(),point[i].y(),_width,_height,QPixmap(":/new/prefix1/towerposition2"));

    }

    for(int i=0;i<16;i++){
        if (tower[i].getstandard()==true&&end==0)//该位置之前没有放过塔且点击了之后绘制塔的图片
      {
           painter.drawPixmap(tower[i].getp().x(),tower[i].getp().y(),60,60,QPixmap(":/new/prefix1/tower3.png"));
           tower[i].sethasTower();
           painter.setPen(Qt::white);
           painter.drawEllipse(QPoint(point[i].x()+20,point[i].y()+20),tower[i].getRange(),tower[i].getRange());

       }
   }

    for(int i=0;i<11;i++){
        if(enemy[i].getlife()&&enemy[i].getlevel()==1&&end==0)
        painter.drawPixmap(enemy[i].getEpo().x(),enemy[i].getEpo().y(),50,50,QPixmap(":/new/prefix1/enemy1.png"));
        if(enemy[i].getlife()&&enemy[i].getlevel()==2&&end==0)
        painter.drawPixmap(enemy[i].getEpo().x(),enemy[i].getEpo().y(),55,55,QPixmap(":/new/prefix1/enermy5.png"));
        if(enemy[i].getlife()&&enemy[i].getlevel()==3&&end==0)
        painter.drawPixmap(enemy[i].getEpo().x(),enemy[i].getEpo().y(),55,55,QPixmap(":/new/prefix1/enemy3.png"));
        if(enemy[i].getlife()&&enemy[i].getlevel()==4&&end==0)
        painter.drawPixmap(enemy[i].getEpo().x(),enemy[i].getEpo().y(),65,65,QPixmap(":/new/prefix1/enemy4.png"));
    }

    if(end==1){

        painter.drawPixmap(180,100,500,300,QPixmap(":/new/prefix1/gameover.png"));
        //QMediaPlayer *play=new QMediaPlayer;
        //play->setMedia(QUrl("qrc:/new/prefix1/fail.mp3"));
        //play->setVolume(30);
        //play->play();

    }
    int add=0;
    for(int i=0;i<11;i++){
       if(enemy[i].getlife()==0&&enemy[i].getEpo().x()>80)
            add+=1;
    }
    if(add==10)
    {
        end=2;
        painter.drawPixmap(180,100,500,300,QPixmap(":/new/prefix1/victory.png"));
    }

}


void MainWindow::mousePressEvent(QMouseEvent *event){
   // if(event->button()==Qt::LeftButton)
    int pressx=event->x();
    int pressy=event->y();

    for(int i=0;i<17;i++){
       if(tower[i].clickrange(pressx,pressy)&&money>=50&&tower[i].gethasTower()==false)
       {

           tower[i].setstandard();//点击之后的触发值
           tower[i].setmusic();
           if(tower[i].gethasTower()==0)
             money=money-50;
       }
       if(tower[i].clickrange(pressx,pressy)&&tower[i].gethasTower()==true)
           tower[i].reSetstandard();


    }
    update();
}
void MainWindow::timerEvent(QTimerEvent *event){

    if(event->timerId()==8){
        if(j<10){

        enemy[j].giveBirth();
        j+=1;
       }


   }
    if(event->timerId()==7){

        for(int i=0;i<11;i++){
            if(enemy[i].getlife()==true){
                enemy[i].Nextposition();
                enemy[i].turn(turn);

            }
            if(enemy[i].getEpo().x()>680&&enemy[i].getlife())
                end=1;
            declareend();

        }
        QString s2=QString::number(money);
        QString s1="Money:";
        QString s=s1.append(s2);
        ui->Money->setText(s);
         getValue();
    }
    if(event->timerId()==9){
        for(int i=0;i<16;i++){
            if(tower[i].getstandard())
            tower[i].attack(enemy);
        }


    }
    update();
    if(event->timerId()==10)
    {
        int add=0;
        for(int i=0;i<1;i++){
           if(enemy[i].getBeattime()==0)
                add+=1;
        }
        if(add==1)
            end=2;

    }


}


MainWindow::~MainWindow()
{
    delete ui;
}



