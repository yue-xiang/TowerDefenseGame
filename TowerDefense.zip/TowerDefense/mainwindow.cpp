#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "tower.h"
#include "enemy.h"
#include <QMouseEvent>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *){
    QPainter painter(this);
   painter.drawPixmap(rect(),QPixmap(":/new/prefix1/map2"),QRect());;
    for(int i=0;i<16;i++){
        painter.drawPixmap(point[i].x(),point[i].y(),_width,_height,QPixmap(":/new/prefix1/towerposition2"));

    }
    for(int i=0;i<16;i++){
        if (tower[i].getstandard()==true)//该位置之前没有放过塔且点击了之后绘制塔的图片
      {
           painter.drawPixmap(tower[i].getp().x(),tower[i].getp().y(),65,65,QPixmap(":/new/prefix1/tower1.png"));

            //tower[i].sethasTower();

       }
   }
    for(int i=0;i<4;i++){
        painter.drawPixmap(turn[i].x(),turn[i].y(),50,50,QPixmap(":/new/prefix1/enemy1.png"));
    }
}


void MainWindow::mousePressEvent(QMouseEvent *event){
   // if(event->button()==Qt::LeftButton)
    int pressx=event->x();
    int pressy=event->y();

    for(int i=0;i<17;i++){
       if(tower[i].clickrange(pressx,pressy))
       {
           tower[i].setstandard();//点击之后的触发值
       }

    }
    update();
}

