#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "tower.h"
#include "enemy.h"
#include <QMouseEvent>
#include <dialog.h>
#include <QTime>
#include <QDebug>

int j=0;
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    startTimer(300);
    startTimer(5000);

}

void MainWindow::paintEvent(QPaintEvent *){
    QPainter painter(this);
   painter.drawPixmap(rect(),QPixmap(":/new/prefix1/map2"),QRect());;
    for(int i=0;i<16;i++){
        painter.drawPixmap(point[i].x(),point[i].y(),_width,_height,QPixmap(":/new/prefix1/towerposition2"));

    }
    for(int i=0;i<16;i++){
        if (tower[i].getstandard()==true)//该位置之前没有放过塔且点击了之后绘制塔的图片
      {
           painter.drawPixmap(tower[i].getp().x(),tower[i].getp().y(),60,60,QPixmap(":/new/prefix1/tower3.png"));

            //tower[i].sethasTower();

       }
   }
    for(int i=0;i<11;i++){
        if(enemy[i].getlife()&&enemy[i].getlevel()==1)
        painter.drawPixmap(enemy[i].getEpo().x(),enemy[i].getEpo().y(),50,50,QPixmap(":/new/prefix1/enemy1.png"));
        if(enemy[i].getlife()&&enemy[i].getlevel()==2)
        painter.drawPixmap(enemy[i].getEpo().x(),enemy[i].getEpo().y(),55,55,QPixmap(":/new/prefix1/enermy5.png"));
        if(enemy[i].getlife()&&enemy[i].getlevel()==3)
        painter.drawPixmap(enemy[i].getEpo().x(),enemy[i].getEpo().y(),55,55,QPixmap(":/new/prefix1/enemy3.png"));
        if(enemy[i].getlife()&&enemy[i].getlevel()==4)
        painter.drawPixmap(enemy[i].getEpo().x(),enemy[i].getEpo().y(),65,65,QPixmap(":/new/prefix1/enemy4.png"));





    }
}


void MainWindow::mousePressEvent(QMouseEvent *event){
   // if(event->button()==Qt::LeftButton)
    int pressx=event->x();
    int pressy=event->y();

    for(int i=0;i<17;i++){
       if(tower[i].clickrange(pressx,pressy))
       {
           tower[i].setstandard();//点击之后的触发值
       }

    }
    update();
}
void MainWindow::timerEvent(QTimerEvent *event){

    if(event->timerId()==6){
        if(j<10){

        enemy[j].giveBirth();
        j+=1;
       }

   }
    if(event->timerId()==5){
        for(int i=0;i<11;i++){
            if(enemy[i].getlife()==true){
                enemy[i].Nextposition();
                enemy[i].turn(turn);
            }
        }
    }
    update();


}

MainWindow::~MainWindow()
{
    delete ui;
}

